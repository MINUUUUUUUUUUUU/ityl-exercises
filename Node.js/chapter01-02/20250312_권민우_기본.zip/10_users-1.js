const user1 = 'Kim';
const user2 = 'Lee';
const user3 = 'Choi';

module.exports = { user1, user2 };
