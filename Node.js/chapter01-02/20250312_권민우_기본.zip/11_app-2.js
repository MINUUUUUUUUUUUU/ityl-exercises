const users = require('./10_users-1');
const hello = require('./08_hello');

hello(users.user1);
hello(users.user2);
