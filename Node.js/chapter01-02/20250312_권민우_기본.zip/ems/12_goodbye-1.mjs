const goodbye = (name) => {
  console.log(`${name} 님, 안녕히 가세요.`);
};

export { goodbye };
