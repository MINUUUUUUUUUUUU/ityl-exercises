import { hi, goodbye } from './14_greeting-1.mjs';

goodbye('길동햄');
