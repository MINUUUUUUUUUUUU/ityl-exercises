import { hi, goodbye } from './14_greeting-1.mjs';

hi('길동햄');
goodbye('길동햄');
