import { goodbye as bye } from './goodbye-1.mjs';

bye('고길동');
