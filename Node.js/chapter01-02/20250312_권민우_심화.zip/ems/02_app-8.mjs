import { hi as hello, goodbye as bye } from './goodbye-1.mjs';

hello('고동');
bye('고동');
