import * as say from './goodbye-1.mjs';

say.hi('자바자바');
say.goodbye('자바자바');
