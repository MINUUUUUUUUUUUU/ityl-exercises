import say from './04_greeting-2.mjs';

say.hi('홍길동');
say.goodbye('홍길동');
