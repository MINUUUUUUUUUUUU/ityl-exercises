const fs = require('fs');

// if (fs.existsSync('text-1.txt')) {
//   console.log('파일 존재');
// } else {
//   fs.writeFileSync('./text-1.txt', data);
// }

if (fs.existsSync('./test')) {
  console.log('디렉토리 존재');
} else {
  fs.mkdirSync('./test', { recursive: true });
}
