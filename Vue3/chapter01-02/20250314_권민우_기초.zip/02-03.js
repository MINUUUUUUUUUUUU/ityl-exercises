const p1 = { name: 'john', age: 20 };
p1.age = 22;
console.log(p1);

p1 = { name: 'lee', age: 25 };

// { name: 'john', age: 22 }
// c:\Users\student\Desktop\CODE_Front\Vue3\chapter01-02\실습_기본\02-03.js:5
// p1 = { name: 'lee', age: 25 };
