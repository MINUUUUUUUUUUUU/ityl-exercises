import { add, multiply } from './modules/02-20-module.js';
import getBase from './modules/02-20-module.js';

console.log(add(5));
console.log(multiply(5));
console.log(getBase());
